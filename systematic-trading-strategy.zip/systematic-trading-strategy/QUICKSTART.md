# Quick Start Guide

Get up and running in 5 minutes!

## 1. Install Dependencies (1 minute)

```bash
pip install -r requirements.txt
```

## 2. Run Your First Analysis (1 minute)

### Analyze Default Portfolio
```bash
python main.py
```

### Analyze Custom Assets
```bash
python main.py AAPL MSFT TSLA BTC-USD
```

## 3. Understand the Output (2 minutes)

You'll see:
- **Summary Table**: Quick overview of all assets
- **Detailed Analysis**: Per-asset breakdown with signals and recommendations
- **JSON Export**: Results saved for further analysis

### Example Output Interpretation

```
Symbol: AAPL
Recommendation: BUY (MODERATE)
Current Price: $268.18

Mean Reversion Strategy:
  Signal: SELL (Price is overbought)
  Z-Score: 2.02
  
Momentum Strategy:
  Signal: BUY (Strong upward trend)
  Momentum: 8.14%

Risk Management:
  Position Size: 10.0% of portfolio
  Stop Loss: $260.23
  Take Profit: $272.16
```

**What This Means:**
- Mean Reversion says SELL (price too high relative to average)
- Momentum says BUY (price trending up)
- Combined recommendation: HOLD (conflicting signals)
- If you buy: Risk $7.95 to make $3.98 (0.50 risk/reward ratio)

## 4. Analyze Your Own Portfolio (1 minute)

Replace symbols with your holdings:

```bash
# Your tech stocks
python main.py AAPL MSFT GOOGL NVDA

# Your crypto holdings
python main.py BTC-USD ETH-USD SOL-USD

# Your diversified portfolio
python main.py SPY BND GLD BTC-USD AAPL
```

## 5. Use Programmatically (Optional)

```python
from strategy import StrategyAnalyzer
import yfinance as yf

# Get data
data = yf.download('AAPL', period='1y', progress=False)['Adj Close']

# Analyze
analyzer = StrategyAnalyzer()
result = analyzer.analyze_asset(data, 'AAPL')

# Use results
if result['recommendation'] == 'BUY':
    print(f"Buy signal detected! Stop loss: ${result['risk_management']['stop_loss']:.2f}")
```

## Common Commands

```bash
# Analyze S&P 500 ETF
python main.py SPY

# Analyze tech stocks
python main.py AAPL MSFT GOOGL NVDA TSLA

# Analyze cryptocurrencies
python main.py BTC-USD ETH-USD XRP-USD

# Analyze commodities
python main.py GLD SLV USO

# Analyze bonds
python main.py BND AGG TLT

# Mixed portfolio
python main.py SPY QQQ BND GLD BTC-USD
```

## Understanding Recommendations

| Recommendation | Meaning | Action |
|---|---|---|
| **BUY (STRONG)** | Very bullish signals | Consider long position |
| **BUY (MODERATE)** | Moderately bullish | Consider small long position |
| **HOLD** | Conflicting signals | Wait for clarity |
| **SELL (MODERATE)** | Moderately bearish | Consider reducing position |
| **SELL (STRONG)** | Very bearish signals | Consider short position |

## Understanding Strategies

### Mean Reversion
- **Concept**: Prices deviate from average, then revert
- **BUY Signal**: Price 2+ std devs BELOW average (oversold)
- **SELL Signal**: Price 2+ std devs ABOVE average (overbought)
- **Best For**: Stable assets (stocks, ETFs)

### Momentum
- **Concept**: Recent winners continue winning
- **BUY Signal**: Strong upward 20-day return
- **SELL Signal**: Strong downward 20-day return
- **Best For**: Trending markets

## Risk Management Explained

```
Current Price: $100
Stop Loss: $95 (5% risk)
Take Profit: $105 (5% reward)
Risk/Reward Ratio: 1.0

If you're right: +$5 profit
If you're wrong: -$5 loss
```

**Position Sizing**: Adjusted for volatility
- High volatility assets → Smaller position
- Low volatility assets → Larger position

## Troubleshooting

### "No module named 'yfinance'"
```bash
pip install yfinance
```

### "Connection error"
- Check internet connection
- Verify ticker symbols are correct
- Try again in a few moments

### "Permission denied"
```bash
chmod +x main.py  # Linux/macOS only
```

## Next Steps

1. **Explore Examples**: Run `python example_usage.py`
2. **Read Full Docs**: Check `README.md` for detailed documentation
3. **Customize**: Modify parameters in `strategy.py`
4. **Integrate**: Use in your own applications
5. **Backtest**: Add historical analysis capabilities

## Important Disclaimers

⚠️ **This is for educational purposes only**
- Not financial advice
- Past performance ≠ future results
- Always do your own research
- Use proper risk management
- Start small and learn

---

**Ready to analyze markets?** 🚀

```bash
python main.py SPY AAPL BTC-USD
```

Happy trading!
