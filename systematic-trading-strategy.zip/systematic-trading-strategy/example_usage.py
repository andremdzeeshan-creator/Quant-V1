"""
Example usage of the Systematic Trading Strategy framework.
Demonstrates how to use the strategy classes programmatically.
"""

import yfinance as yf
from strategy import StrategyAnalyzer, MeanReversionStrategy, MomentumStrategy, RiskManager
import pandas as pd


def example_1_single_asset_analysis():
    """Example 1: Analyze a single asset using both strategies."""
    print("\n" + "="*80)
    print("EXAMPLE 1: Single Asset Analysis (Apple Inc. - AAPL)".center(80))
    print("="*80 + "\n")
    
    # Fetch data
    aapl = yf.download('AAPL', period='1y', progress=False)['Adj Close']
    
    # Create strategy analyzer
    analyzer = StrategyAnalyzer()
    
    # Analyze
    analysis = analyzer.analyze_asset(aapl, 'AAPL')
    
    # Print results
    print(f"Current Price: ${analysis['current_price']:.2f}")
    print(f"Volatility: {analysis['volatility']*100:.2f}%")
    print(f"Recommendation: {analysis['recommendation']} ({analysis['strength']})")
    print(f"\nMean Reversion Signal: {analysis['mean_reversion']['action']}")
    print(f"  Z-Score: {analysis['mean_reversion']['z_score']:.2f}")
    print(f"  Reasoning: {analysis['mean_reversion']['reasoning']}")
    print(f"\nMomentum Signal: {analysis['momentum']['action']}")
    print(f"  Momentum: {analysis['momentum']['momentum']*100:.2f}%")
    print(f"  Reasoning: {analysis['momentum']['reasoning']}")
    print(f"\nRisk Management:")
    print(f"  Position Size: {analysis['risk_management']['suggested_position_size']*100:.1f}%")
    print(f"  Stop Loss: ${analysis['risk_management']['stop_loss']:.2f}")
    print(f"  Take Profit: ${analysis['risk_management']['take_profit']:.2f}")


def example_2_custom_parameters():
    """Example 2: Use custom strategy parameters."""
    print("\n" + "="*80)
    print("EXAMPLE 2: Custom Strategy Parameters (Bitcoin - BTC-USD)".center(80))
    print("="*80 + "\n")
    
    # Fetch data
    btc = yf.download('BTC-USD', period='1y', progress=False)['Adj Close']
    
    # Create strategies with custom parameters
    # For volatile assets like Bitcoin, we use a shorter lookback and higher threshold
    mean_reversion = MeanReversionStrategy(lookback_window=10, z_threshold=1.5)
    momentum = MomentumStrategy(lookback_period=10, top_percentile=0.3)
    
    # Generate signals
    mr_signal = mean_reversion.generate_signal(btc)
    mom_signal = momentum.generate_signal(btc)
    
    print(f"Mean Reversion Signal: {mr_signal['action']}")
    print(f"  Z-Score: {mr_signal['z_score']:.2f}")
    print(f"  Confidence: {mr_signal['confidence']*100:.1f}%")
    print(f"\nMomentum Signal: {mom_signal['action']}")
    print(f"  Momentum: {mom_signal['momentum']*100:.2f}%")
    print(f"  Confidence: {mom_signal['confidence']*100:.1f}%")


def example_3_risk_management():
    """Example 3: Risk management calculations."""
    print("\n" + "="*80)
    print("EXAMPLE 3: Risk Management Calculations (S&P 500 - SPY)".center(80))
    print("="*80 + "\n")
    
    # Fetch data
    spy = yf.download('SPY', period='1y', progress=False)['Adj Close']
    
    # Calculate volatility
    returns = spy.pct_change()
    volatility = returns.std() * (252 ** 0.5)
    
    # Create risk manager
    risk_manager = RiskManager()
    
    # Current price
    current_price = spy.iloc[-1]
    
    # Calculate risk metrics
    position_size = risk_manager.calculate_position_size(volatility)
    stop_loss = risk_manager.calculate_stop_loss(current_price, volatility)
    take_profit = risk_manager.calculate_take_profit(current_price, volatility)
    
    print(f"Current Price: ${current_price:.2f}")
    print(f"Annualized Volatility: {volatility*100:.2f}%")
    print(f"\nRisk Management Recommendations:")
    print(f"  Position Size: {position_size*100:.1f}% of portfolio")
    print(f"  Stop Loss: ${stop_loss:.2f} ({(1 - stop_loss/current_price)*100:.2f}% below entry)")
    print(f"  Take Profit: ${take_profit:.2f} ({(take_profit/current_price - 1)*100:.2f}% above entry)")
    print(f"  Risk/Reward Ratio: {(take_profit - current_price) / (current_price - stop_loss):.2f}")


def example_4_portfolio_comparison():
    """Example 4: Compare multiple assets in a portfolio."""
    print("\n" + "="*80)
    print("EXAMPLE 4: Portfolio Comparison".center(80))
    print("="*80 + "\n")
    
    symbols = ['SPY', 'QQQ', 'GLD', 'BTC-USD', 'AAPL']
    analyzer = StrategyAnalyzer()
    
    results = []
    for symbol in symbols:
        try:
            data = yf.download(symbol, period='1y', progress=False)['Adj Close']
            analysis = analyzer.analyze_asset(data, symbol)
            
            if analysis['status'] == 'OK':
                results.append({
                    'Symbol': symbol,
                    'Price': f"${analysis['current_price']:.2f}",
                    'Volatility': f"{analysis['volatility']*100:.1f}%",
                    'Recommendation': analysis['recommendation'],
                    'Strength': analysis['strength'],
                    'Score': f"{analysis['combined_score']:.2f}"
                })
        except Exception as e:
            print(f"Error analyzing {symbol}: {str(e)}")
    
    # Print as table
    df = pd.DataFrame(results)
    print(df.to_string(index=False))


def example_5_signal_evolution():
    """Example 5: Track signal evolution over time."""
    print("\n" + "="*80)
    print("EXAMPLE 5: Signal Evolution Over Time (Tesla - TSLA)".center(80))
    print("="*80 + "\n")
    
    # Fetch data
    tsla = yf.download('TSLA', period='6mo', progress=False)['Adj Close']
    
    # Create strategy
    mean_reversion = MeanReversionStrategy()
    
    # Calculate Z-scores for the entire period
    z_scores = mean_reversion.calculate_z_score(tsla)
    
    # Show last 10 days
    print("Last 10 trading days - Z-Score Evolution:\n")
    print(f"{'Date':<12} {'Price':<10} {'Z-Score':<10} {'Signal':<12}")
    print("-" * 50)
    
    for i in range(-10, 0):
        date = tsla.index[i].strftime('%Y-%m-%d')
        price = tsla.iloc[i]
        z_score = z_scores.iloc[i]
        
        if z_score < -2.0:
            signal = "BUY (Strong)"
        elif z_score > 2.0:
            signal = "SELL (Strong)"
        elif z_score < -1.0:
            signal = "BUY (Weak)"
        elif z_score > 1.0:
            signal = "SELL (Weak)"
        else:
            signal = "HOLD"
        
        print(f"{date:<12} ${price:<9.2f} {z_score:<10.2f} {signal:<12}")


if __name__ == '__main__':
    print("\n" + "="*80)
    print("SYSTEMATIC TRADING STRATEGY - USAGE EXAMPLES".center(80))
    print("="*80)
    
    # Run examples
    example_1_single_asset_analysis()
    example_2_custom_parameters()
    example_3_risk_management()
    example_4_portfolio_comparison()
    example_5_signal_evolution()
    
    print("\n" + "="*80)
    print("Examples completed!".center(80))
    print("="*80 + "\n")
