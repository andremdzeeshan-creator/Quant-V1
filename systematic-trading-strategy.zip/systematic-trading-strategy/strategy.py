"""
Systematic Trading Strategy Module
Implements mean reversion and momentum strategies with real-time market analysis.
"""

import pandas as pd
import numpy as np
from typing import Dict, Tuple, List
import warnings

warnings.filterwarnings('ignore')


class MeanReversionStrategy:
    """
    Z-score based mean reversion strategy for systematic trading.
    Identifies overbought/oversold conditions and generates trading signals.
    """
    
    def __init__(self, lookback_window: int = 20, z_threshold: float = 2.0):
        """
        Initialize the mean reversion strategy.
        
        Args:
            lookback_window (int): Number of periods for moving average calculation
            z_threshold (float): Z-score threshold for entry signals
        """
        self.lookback_window = lookback_window
        self.z_threshold = z_threshold
        self.last_signal = {}
        self.last_z_score = {}
        
    def calculate_z_score(self, prices: pd.Series) -> pd.Series:
        """
        Calculate Z-score for price series.
        
        Args:
            prices (pd.Series): Historical price data
            
        Returns:
            pd.Series: Z-scores for each period
        """
        rolling_mean = prices.rolling(window=self.lookback_window).mean()
        rolling_std = prices.rolling(window=self.lookback_window).std()
        z_score = (prices - rolling_mean) / rolling_std
        return z_score
    
    def generate_signal(self, prices: pd.Series) -> Dict[str, any]:
        """
        Generate trading signal based on current Z-score.
        
        Args:
            prices (pd.Series): Historical price data
            
        Returns:
            Dict: Signal information including action, z_score, and reasoning
        """
        if len(prices) < self.lookback_window:
            return {
                'action': 'HOLD',
                'z_score': None,
                'reasoning': 'Insufficient data for analysis',
                'confidence': 0.0
            }
        
        z_score = self.calculate_z_score(prices)
        current_z = z_score.iloc[-1]
        previous_z = z_score.iloc[-2] if len(z_score) > 1 else current_z
        
        # Determine signal
        if current_z < -self.z_threshold:
            action = 'BUY'
            reasoning = f'Price is {abs(current_z):.2f} standard deviations below mean. Oversold condition detected.'
            confidence = min(abs(current_z) / (self.z_threshold * 2), 1.0)
        elif current_z > self.z_threshold:
            action = 'SELL'
            reasoning = f'Price is {current_z:.2f} standard deviations above mean. Overbought condition detected.'
            confidence = min(current_z / (self.z_threshold * 2), 1.0)
        elif previous_z < -self.z_threshold and current_z >= 0:
            action = 'CLOSE_LONG'
            reasoning = 'Price has reverted to mean. Exit long position.'
            confidence = 0.8
        elif previous_z > self.z_threshold and current_z <= 0:
            action = 'CLOSE_SHORT'
            reasoning = 'Price has reverted to mean. Exit short position.'
            confidence = 0.8
        else:
            action = 'HOLD'
            reasoning = f'Price is within normal range (Z-score: {current_z:.2f}). No action needed.'
            confidence = 0.5
        
        return {
            'action': action,
            'z_score': current_z,
            'reasoning': reasoning,
            'confidence': confidence,
            'current_price': prices.iloc[-1],
            'moving_average': prices.rolling(window=self.lookback_window).mean().iloc[-1]
        }


class MomentumStrategy:
    """
    Relative strength momentum strategy for systematic trading.
    Identifies trending assets and generates directional signals.
    """
    
    def __init__(self, lookback_period: int = 20, top_percentile: float = 0.2):
        """
        Initialize the momentum strategy.
        
        Args:
            lookback_period (int): Number of periods for return calculation
            top_percentile (float): Percentile for top/bottom performers
        """
        self.lookback_period = lookback_period
        self.top_percentile = top_percentile
        
    def calculate_returns(self, prices: pd.Series) -> float:
        """
        Calculate period returns.
        
        Args:
            prices (pd.Series): Historical price data
            
        Returns:
            float: Period return as percentage
        """
        if len(prices) < self.lookback_period:
            return 0.0
        
        return (prices.iloc[-1] - prices.iloc[-self.lookback_period]) / prices.iloc[-self.lookback_period]
    
    def generate_signal(self, prices: pd.Series, benchmark_return: float = 0.0) -> Dict[str, any]:
        """
        Generate trading signal based on momentum.
        
        Args:
            prices (pd.Series): Historical price data
            benchmark_return (float): Benchmark return for comparison
            
        Returns:
            Dict: Signal information including action and reasoning
        """
        if len(prices) < self.lookback_period:
            return {
                'action': 'HOLD',
                'momentum': None,
                'reasoning': 'Insufficient data for momentum analysis',
                'confidence': 0.0
            }
        
        momentum = self.calculate_returns(prices)
        
        if momentum > benchmark_return * (1 + self.top_percentile):
            action = 'BUY'
            reasoning = f'Strong upward momentum detected ({momentum*100:.2f}% return). Asset is trending up.'
            confidence = min(abs(momentum) / 0.1, 1.0)  # Normalize to 0-1
        elif momentum < benchmark_return * (1 - self.top_percentile):
            action = 'SELL'
            reasoning = f'Strong downward momentum detected ({momentum*100:.2f}% return). Asset is trending down.'
            confidence = min(abs(momentum) / 0.1, 1.0)
        else:
            action = 'HOLD'
            reasoning = f'Momentum is neutral ({momentum*100:.2f}% return). No clear trend.'
            confidence = 0.5
        
        return {
            'action': action,
            'momentum': momentum,
            'reasoning': reasoning,
            'confidence': confidence,
            'current_price': prices.iloc[-1],
            'return_period': f'{self.lookback_period} days'
        }


class RiskManager:
    """
    Manages position sizing and risk controls based on volatility.
    """
    
    def __init__(self, max_position_size: float = 0.1, max_portfolio_loss: float = 0.05):
        """
        Initialize the risk manager.
        
        Args:
            max_position_size (float): Maximum position size as fraction of portfolio
            max_portfolio_loss (float): Maximum acceptable portfolio loss
        """
        self.max_position_size = max_position_size
        self.max_portfolio_loss = max_portfolio_loss
        
    def calculate_position_size(self, volatility: float, base_size: float = 1.0) -> float:
        """
        Calculate position size based on volatility (inverse volatility weighting).
        
        Args:
            volatility (float): Asset volatility (annualized)
            base_size (float): Base position size
            
        Returns:
            float: Adjusted position size
        """
        if volatility == 0:
            return base_size
        
        # Inverse volatility weighting: higher volatility = smaller position
        adjusted_size = base_size / volatility
        return min(adjusted_size, self.max_position_size)
    
    def calculate_stop_loss(self, entry_price: float, volatility: float, multiplier: float = 2.0) -> float:
        """
        Calculate stop-loss level based on volatility.
        
        Args:
            entry_price (float): Entry price
            volatility (float): Asset volatility (annualized)
            multiplier (float): Volatility multiplier for stop-loss
            
        Returns:
            float: Stop-loss price
        """
        daily_volatility = volatility / np.sqrt(252)
        stop_loss = entry_price * (1 - daily_volatility * multiplier)
        return stop_loss
    
    def calculate_take_profit(self, entry_price: float, volatility: float, multiplier: float = 1.0) -> float:
        """
        Calculate take-profit level based on volatility.
        
        Args:
            entry_price (float): Entry price
            volatility (float): Asset volatility (annualized)
            multiplier (float): Volatility multiplier for take-profit
            
        Returns:
            float: Take-profit price
        """
        daily_volatility = volatility / np.sqrt(252)
        take_profit = entry_price * (1 + daily_volatility * multiplier)
        return take_profit


class StrategyAnalyzer:
    """
    Analyzes multiple strategies and provides comprehensive trading advice.
    """
    
    def __init__(self):
        """Initialize the strategy analyzer with default strategies."""
        self.mean_reversion = MeanReversionStrategy(lookback_window=20, z_threshold=2.0)
        self.momentum = MomentumStrategy(lookback_period=20, top_percentile=0.2)
        self.risk_manager = RiskManager()
        
    def analyze_asset(self, prices: pd.Series, symbol: str) -> Dict[str, any]:
        """
        Perform comprehensive analysis on an asset using multiple strategies.
        
        Args:
            prices (pd.Series): Historical price data
            symbol (str): Asset symbol
            
        Returns:
            Dict: Comprehensive analysis including signals and recommendations
        """
        if len(prices) < 20:
            return {
                'symbol': symbol,
                'status': 'ERROR',
                'message': 'Insufficient historical data (minimum 20 periods required)',
                'recommendation': 'HOLD'
            }
        
        # Calculate volatility
        returns = prices.pct_change()
        volatility = returns.std() * np.sqrt(252)
        
        # Generate signals from both strategies
        mean_reversion_signal = self.mean_reversion.generate_signal(prices)
        momentum_signal = self.momentum.generate_signal(prices)
        
        # Combine signals with weighted voting
        mr_weight = 0.6
        mom_weight = 0.4
        
        # Convert actions to scores
        action_scores = {
            'BUY': 1.0,
            'SELL': -1.0,
            'CLOSE_LONG': -0.5,
            'CLOSE_SHORT': 0.5,
            'HOLD': 0.0
        }
        
        mr_score = action_scores.get(mean_reversion_signal['action'], 0) * mr_weight
        mom_score = action_scores.get(momentum_signal['action'], 0) * mom_weight
        combined_score = mr_score + mom_score
        
        # Determine final recommendation
        if combined_score > 0.3:
            recommendation = 'BUY'
            strength = 'STRONG' if combined_score > 0.6 else 'MODERATE'
        elif combined_score < -0.3:
            recommendation = 'SELL'
            strength = 'STRONG' if combined_score < -0.6 else 'MODERATE'
        else:
            recommendation = 'HOLD'
            strength = 'NEUTRAL'
        
        # Calculate position sizing and risk levels
        position_size = self.risk_manager.calculate_position_size(volatility)
        stop_loss = self.risk_manager.calculate_stop_loss(prices.iloc[-1], volatility)
        take_profit = self.risk_manager.calculate_take_profit(prices.iloc[-1], volatility)
        
        return {
            'symbol': symbol,
            'status': 'OK',
            'current_price': prices.iloc[-1],
            'volatility': volatility,
            'recommendation': recommendation,
            'strength': strength,
            'combined_score': combined_score,
            'mean_reversion': mean_reversion_signal,
            'momentum': momentum_signal,
            'risk_management': {
                'suggested_position_size': position_size,
                'stop_loss': stop_loss,
                'take_profit': take_profit,
                'risk_reward_ratio': (take_profit - prices.iloc[-1]) / (prices.iloc[-1] - stop_loss) if prices.iloc[-1] != stop_loss else 0
            }
        }
