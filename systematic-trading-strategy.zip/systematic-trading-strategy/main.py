"""
Systematic Trading Strategy - Real-Time Market Analysis Tool
Analyzes current market conditions and provides trading recommendations.
"""

import yfinance as yf
import pandas as pd
from datetime import datetime, timedelta
import sys
from strategy import StrategyAnalyzer
from tabulate import tabulate
import json


class TradingAdvisor:
    """
    Real-time trading advisor that analyzes market conditions and provides recommendations.
    """
    
    def __init__(self):
        """Initialize the trading advisor."""
        self.analyzer = StrategyAnalyzer()
        self.analysis_results = {}
        
    def fetch_market_data(self, symbols: list, period: str = '1y') -> dict:
        """
        Fetch historical market data for given symbols.
        
        Args:
            symbols (list): List of asset symbols (e.g., ['SPY', 'BTC-USD', 'AAPL'])
            period (str): Historical period ('1y', '6mo', '3mo', '1mo', '1w', '1d')
            
        Returns:
            dict: Dictionary of symbol -> price series
        """
        print(f"\n📊 Fetching market data for {len(symbols)} assets (period: {period})...")
        
        data = {}
        for symbol in symbols:
            try:
                print(f"  ⏳ Downloading {symbol}...", end=' ')
                prices = yf.download(symbol, period=period, progress=False)
                
                # Handle MultiIndex columns (when downloading single or multiple symbols)
                if isinstance(prices.columns, pd.MultiIndex):
                    # MultiIndex case: extract price column for this symbol
                    if ('Adj Close', symbol) in prices.columns:
                        prices = prices[('Adj Close', symbol)]
                    elif ('Close', symbol) in prices.columns:
                        prices = prices[('Close', symbol)]
                    else:
                        # Fallback: take first price-like column
                        prices = prices.iloc[:, 0]
                else:
                    # Single column case
                    if 'Adj Close' in prices.columns:
                        prices = prices['Adj Close']
                    elif 'Close' in prices.columns:
                        prices = prices['Close']
                    else:
                        prices = prices.iloc[:, 0]
                
                # Forward fill and drop NaN
                prices = prices.ffill().dropna()
                
                data[symbol] = prices
                print("✓")
            except Exception as e:
                print(f"✗ Error: {str(e)}")
                continue
        
        return data
    
    def analyze_portfolio(self, symbols: list, period: str = '1y') -> dict:
        """
        Analyze a portfolio of assets and generate recommendations.
        
        Args:
            symbols (list): List of asset symbols
            period (str): Historical period for analysis
            
        Returns:
            dict: Analysis results for all symbols
        """
        # Fetch data
        market_data = self.fetch_market_data(symbols, period)
        
        if not market_data:
            print("❌ No data retrieved. Please check symbols and try again.")
            return {}
        
        # Analyze each asset
        print(f"\n🔍 Analyzing {len(market_data)} assets...\n")
        
        results = {}
        for symbol, prices in market_data.items():
            analysis = self.analyzer.analyze_asset(prices, symbol)
            results[symbol] = analysis
            self.analysis_results[symbol] = analysis
        
        return results
    
    def print_analysis_summary(self, results: dict):
        """
        Print a formatted summary of analysis results.
        
        Args:
            results (dict): Analysis results from analyze_portfolio
        """
        print("\n" + "="*100)
        print("TRADING RECOMMENDATION SUMMARY".center(100))
        print("="*100 + "\n")
        
        # Summary table
        summary_data = []
        for symbol, analysis in results.items():
            if analysis['status'] == 'OK':
                summary_data.append([
                    symbol,
                    f"${analysis['current_price']:.2f}",
                    f"{analysis['volatility']*100:.2f}%",
                    analysis['recommendation'],
                    analysis['strength'],
                    f"{analysis['combined_score']:.2f}"
                ])
        
        headers = ["Symbol", "Price", "Volatility", "Recommendation", "Strength", "Score"]
        print(tabulate(summary_data, headers=headers, tablefmt="grid"))
        
        # Detailed analysis for each asset
        print("\n" + "="*100)
        print("DETAILED ANALYSIS".center(100))
        print("="*100 + "\n")
        
        for symbol, analysis in results.items():
            if analysis['status'] != 'OK':
                print(f"⚠️  {symbol}: {analysis['message']}\n")
                continue
            
            print(f"{'='*50}")
            print(f"📈 {symbol}")
            print(f"{'='*50}")
            print(f"Current Price:        ${analysis['current_price']:.2f}")
            print(f"Volatility (Annual):  {analysis['volatility']*100:.2f}%")
            print(f"Recommendation:       {analysis['recommendation']} ({analysis['strength']})")
            print(f"Combined Score:       {analysis['combined_score']:.2f}\n")
            
            # Mean Reversion Analysis
            mr = analysis['mean_reversion']
            print(f"Mean Reversion Strategy:")
            print(f"  Signal:             {mr['action']}")
            print(f"  Z-Score:            {mr['z_score']:.2f}")
            print(f"  Confidence:         {mr['confidence']*100:.1f}%")
            print(f"  Reasoning:          {mr['reasoning']}\n")
            
            # Momentum Analysis
            mom = analysis['momentum']
            print(f"Momentum Strategy:")
            print(f"  Signal:             {mom['action']}")
            print(f"  Momentum:           {mom['momentum']*100:.2f}%")
            print(f"  Confidence:         {mom['confidence']*100:.1f}%")
            print(f"  Reasoning:          {mom['reasoning']}\n")
            
            # Risk Management
            rm = analysis['risk_management']
            print(f"Risk Management:")
            print(f"  Position Size:      {rm['suggested_position_size']*100:.1f}% of portfolio")
            print(f"  Stop Loss:          ${rm['stop_loss']:.2f}")
            print(f"  Take Profit:        ${rm['take_profit']:.2f}")
            print(f"  Risk/Reward Ratio:  {rm['risk_reward_ratio']:.2f}\n")
    
    def export_results_json(self, results: dict, filename: str = 'trading_analysis.json'):
        """
        Export analysis results to JSON file.
        
        Args:
            results (dict): Analysis results
            filename (str): Output filename
        """
        import numpy as np
        
        # Convert numpy types to native Python types for JSON serialization
        def convert_types(obj):
            if isinstance(obj, (pd.Timestamp, datetime)):
                return obj.isoformat()
            elif isinstance(obj, (np.integer, np.floating)):
                return float(obj)
            elif isinstance(obj, dict):
                return {k: convert_types(v) for k, v in obj.items()}
            elif isinstance(obj, (list, tuple)):
                return [convert_types(item) for item in obj]
            return obj
        
        converted_results = convert_types(results)
        
        with open(filename, 'w') as f:
            json.dump(converted_results, f, indent=2)
        
        print(f"\n✅ Results exported to {filename}")


def main():
    """Main entry point for the trading advisor."""
    
    print("\n" + "="*100)
    print("SYSTEMATIC TRADING STRATEGY - REAL-TIME MARKET ADVISOR".center(100))
    print("="*100)
    
    advisor = TradingAdvisor()
    
    # Default portfolio for demonstration
    default_symbols = ['SPY', 'BTC-USD', 'AAPL', 'QQQ', 'GLD']
    
    # Allow custom symbols via command line
    if len(sys.argv) > 1:
        symbols = sys.argv[1:]
        print(f"\n📋 Analyzing custom portfolio: {', '.join(symbols)}")
    else:
        symbols = default_symbols
        print(f"\n📋 Analyzing default portfolio: {', '.join(symbols)}")
        print("💡 Tip: Run with custom symbols: python main.py AAPL MSFT TSLA")
    
    # Analyze portfolio
    results = advisor.analyze_portfolio(symbols, period='1y')
    
    # Print summary
    advisor.print_analysis_summary(results)
    
    # Export results
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    advisor.export_results_json(results, f'trading_analysis_{timestamp}.json')
    
    print("\n" + "="*100)
    print("Analysis complete. Check the JSON file for detailed results.".center(100))
    print("="*100 + "\n")


if __name__ == '__main__':
    main()
