# Installation & Setup Guide

## Prerequisites

- Python 3.8 or higher
- pip (Python package manager)
- Git (optional, for cloning the repository)

## Step 1: Clone or Download the Repository

### Option A: Clone from GitHub
```bash
git clone https://github.com/yourusername/systematic-trading-strategy.git
cd systematic-trading-strategy
```

### Option B: Download as ZIP
Download the repository as a ZIP file and extract it to your desired location.

## Step 2: Create a Virtual Environment (Recommended)

A virtual environment isolates project dependencies and prevents conflicts with system packages.

### On macOS/Linux:
```bash
python3 -m venv venv
source venv/bin/activate
```

### On Windows:
```bash
python -m venv venv
venv\Scripts\activate
```

## Step 3: Install Dependencies

```bash
pip install -r requirements.txt
```

This installs all required packages:
- `yfinance` - For fetching market data
- `pandas` - For data manipulation
- `numpy` - For numerical computations
- `tabulate` - For formatted table output
- `matplotlib` - For plotting
- `seaborn` - For statistical visualizations

## Step 4: Verify Installation

Test that everything is working correctly:

```bash
python main.py SPY AAPL
```

You should see a formatted output with trading recommendations for SPY and AAPL.

## Troubleshooting

### Issue: `ModuleNotFoundError: No module named 'yfinance'`

**Solution**: Ensure you've activated the virtual environment and installed requirements:
```bash
source venv/bin/activate  # or venv\Scripts\activate on Windows
pip install -r requirements.txt
```

### Issue: `Connection error` when downloading data

**Solution**: This typically means yfinance cannot reach Yahoo Finance servers. Try:
1. Check your internet connection
2. Wait a few moments and try again
3. Verify the stock symbol is correct (e.g., 'AAPL' not 'Apple')

### Issue: `Permission denied` on Linux/macOS

**Solution**: Make the script executable:
```bash
chmod +x main.py
```

### Issue: Python version incompatibility

**Solution**: Ensure you're using Python 3.8+:
```bash
python --version
# or
python3 --version
```

If you have multiple Python versions installed, explicitly use Python 3.8+:
```bash
python3.8 main.py SPY AAPL
# or
python3.11 main.py SPY AAPL
```

## Usage Examples

### Basic Usage - Default Portfolio
```bash
python main.py
```

### Analyze Specific Stocks
```bash
python main.py AAPL MSFT GOOGL
```

### Analyze Cryptocurrencies
```bash
python main.py BTC-USD ETH-USD
```

### Mixed Portfolio
```bash
python main.py SPY QQQ BTC-USD AAPL GLD
```

### Run Example Scripts
```bash
python example_usage.py
```

## Understanding the Output

### Summary Table
Shows quick overview of all analyzed assets:
- **Symbol**: Ticker symbol
- **Price**: Current price
- **Volatility**: Annualized volatility (%)
- **Recommendation**: BUY, SELL, or HOLD
- **Strength**: STRONG, MODERATE, or NEUTRAL
- **Score**: Combined signal score (-1 to +1)

### Detailed Analysis
For each asset, you'll see:

1. **Mean Reversion Strategy**
   - Signal: Entry/exit action
   - Z-Score: How many standard deviations from mean
   - Confidence: Signal confidence level
   - Reasoning: Explanation of the signal

2. **Momentum Strategy**
   - Signal: Trending direction
   - Momentum: Percentage return over lookback period
   - Confidence: Signal confidence level
   - Reasoning: Explanation of the signal

3. **Risk Management**
   - Position Size: Suggested portfolio allocation
   - Stop Loss: Recommended stop-loss price
   - Take Profit: Recommended take-profit price
   - Risk/Reward Ratio: Potential reward vs. risk

### JSON Export
Results are automatically exported to `trading_analysis_YYYYMMDD_HHMMSS.json` for programmatic access.

## Advanced Usage

### Using the Strategy Classes Directly

```python
from strategy import StrategyAnalyzer, MeanReversionStrategy, RiskManager
import yfinance as yf

# Download data
data = yf.download('AAPL', period='1y', progress=False)['Adj Close']

# Create analyzer
analyzer = StrategyAnalyzer()

# Analyze asset
analysis = analyzer.analyze_asset(data, 'AAPL')

# Access results
print(f"Recommendation: {analysis['recommendation']}")
print(f"Current Price: ${analysis['current_price']:.2f}")
print(f"Stop Loss: ${analysis['risk_management']['stop_loss']:.2f}")
```

### Custom Strategy Parameters

```python
from strategy import MeanReversionStrategy

# Create strategy with custom parameters
strategy = MeanReversionStrategy(lookback_window=10, z_threshold=1.5)

# Generate signal
signal = strategy.generate_signal(data)
print(signal)
```

## Performance Optimization

For analyzing large portfolios, consider:

1. **Batch Processing**: Download data once, analyze multiple times
2. **Caching**: Store downloaded data to avoid repeated API calls
3. **Parallel Processing**: Use multiprocessing for multiple assets

Example:
```python
from concurrent.futures import ThreadPoolExecutor
from strategy import StrategyAnalyzer
import yfinance as yf

symbols = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'TSLA']
analyzer = StrategyAnalyzer()

def analyze_symbol(symbol):
    data = yf.download(symbol, period='1y', progress=False)['Adj Close']
    return analyzer.analyze_asset(data, symbol)

with ThreadPoolExecutor(max_workers=5) as executor:
    results = list(executor.map(analyze_symbol, symbols))
```

## Next Steps

1. **Explore the Code**: Review `strategy.py` to understand the implementation
2. **Run Examples**: Execute `example_usage.py` to see various use cases
3. **Customize**: Modify parameters in `strategy.py` for your needs
4. **Integrate**: Use the classes in your own applications
5. **Backtest**: Extend with historical backtesting capabilities

## Support & Documentation

- **README.md**: Overview and feature description
- **strategy.py**: Detailed docstrings for all classes
- **example_usage.py**: Practical usage examples
- **main.py**: Real-time market analysis tool

## Important Reminders

⚠️ **This tool is for educational and research purposes only.**
- Not financial advice
- Past performance ≠ future results
- Always do your own research before trading
- Use proper risk management
- Start with small positions

Happy trading! 📈
