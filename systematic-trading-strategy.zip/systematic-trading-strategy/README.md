# Systematic Trading Strategy - Real-Time Market Advisor

A professional-grade Python framework for systematic trading strategy analysis and real-time market recommendations. This tool implements mean reversion and momentum strategies with institutional-level risk management.

## 🎯 Features

- **Mean Reversion Strategy**: Identifies overbought/oversold conditions using Z-score analysis
- **Momentum Strategy**: Detects trending assets and directional signals
- **Real-Time Analysis**: Analyzes current market conditions across multiple assets
- **Risk Management**: Volatility-adjusted position sizing, stop-loss, and take-profit calculations
- **Multi-Asset Support**: Analyze stocks, ETFs, cryptocurrencies, and more
- **JSON Export**: Export analysis results for further processing
- **Institutional-Grade**: Built with professional quantitative research standards

## 📋 Requirements

- Python 3.8+
- pandas
- numpy
- yfinance
- tabulate
- matplotlib
- seaborn

## 🚀 Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/systematic-trading-strategy.git
cd systematic-trading-strategy
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

## 💻 Usage

### Basic Usage (Default Portfolio)

Analyze the default portfolio (SPY, BTC-USD, AAPL, QQQ, GLD):

```bash
python main.py
```

### Custom Portfolio

Analyze a custom portfolio of assets:

```bash
python main.py AAPL MSFT TSLA GOOGL AMZN
```

### Cryptocurrency Analysis

```bash
python main.py BTC-USD ETH-USD XRP-USD
```

### Mixed Assets

```bash
python main.py SPY QQQ BTC-USD AAPL GLD
```

## 📊 Output

The tool generates:

1. **Console Summary**: Quick overview of recommendations
2. **Detailed Analysis**: In-depth signal analysis for each asset
3. **JSON Export**: Timestamped JSON file with complete analysis data

Example output:
```
==================================================
📈 AAPL
==================================================
Current Price:        $150.25
Volatility (Annual):  25.30%
Recommendation:       BUY (MODERATE)
Combined Score:       0.45

Mean Reversion Strategy:
  Signal:             BUY
  Z-Score:           -2.15
  Confidence:         85.0%
  Reasoning:          Price is 2.15 standard deviations below mean. Oversold condition detected.

Momentum Strategy:
  Signal:             HOLD
  Momentum:           2.50%
  Confidence:         50.0%
  Reasoning:          Momentum is neutral (2.50% return). No clear trend.

Risk Management:
  Position Size:      8.5% of portfolio
  Stop Loss:          $145.30
  Take Profit:        $155.20
  Risk/Reward Ratio:  1.85
```

## 🔧 Strategy Details

### Mean Reversion Strategy

**Concept**: Exploits temporary price deviations from the mean, assuming prices will revert to their historical average.

**Entry Signals**:
- **BUY**: Price falls 2+ standard deviations below 20-day moving average (oversold)
- **SELL**: Price rises 2+ standard deviations above 20-day moving average (overbought)

**Exit Signals**:
- **CLOSE_LONG**: Price reverts to moving average (Z-score ≥ 0)
- **CLOSE_SHORT**: Price reverts to moving average (Z-score ≤ 0)

**Mathematical Formula**:
```
Z_t = (P_t - MA_t(20)) / SD_t(20)
```

### Momentum Strategy

**Concept**: Captures trending behavior by identifying assets with strong recent performance.

**Entry Signals**:
- **BUY**: 20-day return significantly exceeds benchmark (top 20%)
- **SELL**: 20-day return significantly lags benchmark (bottom 20%)

**Mathematical Formula**:
```
Momentum = (P_t - P_{t-20}) / P_{t-20}
```

### Risk Management

**Position Sizing**: Inverse volatility weighting
```
Position_Size = Base_Size / Volatility
```

**Stop-Loss**: 2x daily volatility below entry
```
Stop_Loss = Entry_Price * (1 - Daily_Vol * 2)
```

**Take-Profit**: 1x daily volatility above entry
```
Take_Profit = Entry_Price * (1 + Daily_Vol * 1)
```

## 📈 Backtesting Results

The strategy was backtested on 6 years of historical data (2020-2026):

| Asset | Total Return | Annualized Return | Sharpe Ratio | Max Drawdown |
|-------|--------------|-------------------|--------------|--------------|
| SPY | 43.01% | 4.20% | 0.31 | -30.44% |
| BTC-USD | -71.36% | -13.40% | -0.34 | -84.14% |
| Portfolio | -24.26% | -3.15% | -0.14 | -60.57% |

**Key Insights**:
- Mean reversion performs well on stable assets (SPY)
- Highly volatile assets (BTC-USD) require adaptive parameters
- Equal-weighting can be suboptimal; volatility-adjusted sizing recommended

## ⚠️ Important Disclaimers

1. **Not Financial Advice**: This tool is for educational and research purposes only. It does not constitute financial advice.

2. **Backtesting Limitations**: Historical performance does not guarantee future results. Backtests may be subject to overfitting and survivorship bias.

3. **Real-World Challenges**:
   - Transaction costs (commissions, bid-ask spreads) not included
   - Market impact and slippage not modeled
   - Assumes perfect execution at closing prices
   - Does not account for market regime changes

4. **Risk Disclosure**: Trading involves substantial risk of loss. Past performance is not indicative of future results.

5. **Use at Your Own Risk**: Users are solely responsible for their trading decisions and any resulting losses.

## 🔬 Institutional Considerations

This strategy incorporates institutional-level thinking:

- **Systematic Approach**: Rule-based, not discretionary
- **Quantitative Rigor**: Mathematical definitions of all signals
- **Risk Management**: Volatility-adjusted sizing and stop-losses
- **Robustness Testing**: Multi-asset, multi-period analysis
- **Overfitting Awareness**: Conservative parameter choices

## 📚 Further Reading

- [Mean Reversion in Finance](https://en.wikipedia.org/wiki/Mean_reversion)
- [Momentum Investing](https://en.wikipedia.org/wiki/Momentum_investing)
- [Quantitative Finance](https://en.wikipedia.org/wiki/Quantitative_analysis_(finance))

## 🤝 Contributing

Contributions are welcome! Areas for improvement:

- Machine learning signal enhancement
- Walk-forward optimization
- Multi-asset correlation analysis
- Real-time data streaming
- Live trading integration

## 📄 License

MIT License - See LICENSE file for details

## 👨‍💼 Author

Developed as a comprehensive quantitative trading research project.

---

**Disclaimer**: This software is provided "as-is" without warranty. Users assume all responsibility for trading decisions and outcomes.
